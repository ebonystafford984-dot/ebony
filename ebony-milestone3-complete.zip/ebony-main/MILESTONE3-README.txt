Milestone 3 update

Files changed/added:
- index.html: adds a show/hide learning-tip interaction.
- projects.html: adds a bonus API demo section.
- script.js: DOM event handlers and API fetch with error handling.
- styles.css: styles for interactive states and API demo.

The contact form validation in about.html was already present in the supplied files and has been preserved. It uses inline field errors, aria-invalid, focus on the first invalid field, and does not pretend to send messages.

To publish: upload/replace these files in your GitHub repository (index.html, projects.html, styles.css, script.js, and this note if desired) and commit the changes.
