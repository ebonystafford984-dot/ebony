// Milestone 3: interactive DOM behavior and optional API example.
document.addEventListener("DOMContentLoaded", () => {
  // Homepage interaction: reveal/hide a learning tip without reloading.
  const tipButton = document.querySelector("#tip-button");
  const learningTip = document.querySelector("#learning-tip");
  if (tipButton && learningTip) {
    tipButton.addEventListener("click", () => {
      const willShow = learningTip.hidden;
      learningTip.hidden = !willShow;
      tipButton.textContent = willShow ? "Hide learning tip" : "Show a learning tip";
      tipButton.setAttribute("aria-expanded", String(willShow));
    });
  }

  // Bonus API interaction: request a sample post, with loading and error states.
  const loadButton = document.querySelector("#load-project-button");
  const apiStatus = document.querySelector("#api-status");
  const projectCard = document.querySelector("#api-project");
  const projectTitle = document.querySelector("#api-project-title");
  const projectDescription = document.querySelector("#api-project-description");
  if (loadButton && apiStatus && projectCard && projectTitle && projectDescription) {
    loadButton.addEventListener("click", async () => {
      loadButton.disabled = true;
      apiStatus.textContent = "Loading sample project…";
      projectCard.hidden = true;
      try {
        const response = await fetch("https://jsonplaceholder.typicode.com/posts/1");
        if (!response.ok) throw new Error("The server returned an error.");
        const data = await response.json();
        projectTitle.textContent = data.title || "Sample project";
        projectDescription.textContent = data.body || "Sample data loaded successfully.";
        projectCard.hidden = false;
        apiStatus.textContent = "Sample data loaded successfully.";
      } catch (error) {
        apiStatus.textContent = "Could not load sample data. Please try again later.";
      } finally {
        loadButton.disabled = false;
      }
    });
  }
});
